#include <stdio.h>

int main() {
  printf("%d\n", 1);

  return 0;
}
